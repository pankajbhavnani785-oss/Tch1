# TCH Kitchenware — Android APK + Live Backend

## 1. MongoDB Atlas
Create a MongoDB Atlas database and copy its connection string.

Use database name `tch_kitchenware`.

For initial testing, allow the backend host to connect to MongoDB. Prefer restricting access to the hosting provider's outbound IPs for production if your plan supports it.

## 2. Deploy FastAPI backend
This repository includes `render.yaml` and `backend/Dockerfile`.

On Render, create a Blueprint from this repository. Set:
- `MONGO_URL` = your MongoDB Atlas connection string
- `JWT_SECRET` = generated automatically by Render
- `DB_NAME` = `tch_kitchenware`

After deployment, verify:
`https://YOUR-BACKEND-DOMAIN/api/`

It should return JSON containing `TCH Kitchenware API`.

## 3. Configure Expo/EAS
From `frontend/`:

```bash
npm install
npx expo login
npx eas build:configure
```

Set the production API URL when building:

```bash
EXPO_PUBLIC_BACKEND_URL=https://YOUR-BACKEND-DOMAIN npx eas build --platform android --profile production
```

The included `eas.json` produces an installable APK.

## 4. Install APK
When EAS finishes, open the build URL on your Android phone and install the APK.

## Default admin account
The backend seeds:
- identifier: `admin@tch.in`
- password: `TCHAdmin@123`

Change the admin password/authentication implementation before distributing the app publicly. Do not leave a known default admin password in production.
